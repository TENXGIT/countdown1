import React from "react"
import { useState } from "react"



const Count=()=>{
     
    const [data,setdata]=useState(0)
    const handelclick=()=>{
      const k=document.getElementById("bharath")
      let val=k.value
     setInterval(() => {
         if(val!==0){
         setdata(val=val-1)
         }
      }, 1000);
      
        
     }
     const handelchange=()=>{
      setdata(0)
      
     }
     
     return(
      <div>
         <center>
            <input onChange={handelchange} id="bharath"/>
      <button onClick={handelclick}>click</button><br/>
      <div>{data}</div>
      </center>
      </div>
        
        
     )
}


export default Count