import Count from "./components/timmer"
function App() {
  return (
    <div className="App">
      
      <Count/>
      
      
    </div>
  );
}

export default App;
